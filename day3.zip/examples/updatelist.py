
#rite a program to define list of integers as below and convert them to the strings.
#numbers = [1,2,3]



alist = [1,2,3]

blist = []
for val in alist:
   blist.append(str(val))

print(blist)


## single liner
alist = [1,2,3]
print(list(map(str,alist)))
