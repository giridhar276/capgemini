
# function body
def display(a,b):
    c  = a + b
    return c

# calling function
total = display(10,20)
print(total)
