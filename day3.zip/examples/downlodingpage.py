### method2
# using REST API call
import requests
from bs4 import BeautifulSoup

response = requests.get("https://www.python.org")

print(response.status_code)

if response.status_code == 200 :
    soup = BeautifulSoup(response.text, 'html.parser')
    # step4 : display all a tags
    for url in soup.find_all('a'):
        #print(url)
        print(url.get('href'))

