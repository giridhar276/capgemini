



alist = [10,20,30] 
alist.reverse() 
print(alist)
