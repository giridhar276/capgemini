


import urllib.request as url
url.urlretrieve("https://www.python.org", "python.html")

