


# function body
# here info object is the tuple
def display(*info):
    for val in info:
        print(val)

# calling function
display(10,20,30,4,5,5,3,3,5,34,343,2,3,34343)

