


import json

# reading json as file object
fobj = open("fruitinfo.json","r")

# converting the file object to json object
reader = json.load(fobj)

#print(reader)

for item in reader:
    print("key  :", item)
    print("Value:",reader[item])
    print("------------")
