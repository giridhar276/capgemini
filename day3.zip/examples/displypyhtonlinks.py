


from bs4 import BeautifulSoup

# step 1: download the required page
import urllib.request as url
url.urlretrieve("https://www.python.org", "python.html")

# step 2: read the downloaded page
fobj = open("python.html","r")
# convert the html as the single string
content = fobj.read()
fobj.close()

# step3 : passing content string(above one ) as the input to bs4
soup = BeautifulSoup(content, 'html.parser')

# step4 : display all a tags
for url in soup.find_all('a'):
    print(url)
