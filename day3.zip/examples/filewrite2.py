


fobj =open("output.txt","w")

fobj.writelines(['10','20','30'])

fobj.close()
