import os

for file in os.listdir():
    print(file)




