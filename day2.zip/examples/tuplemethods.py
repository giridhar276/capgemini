

atup = (10,20)

print(atup)

