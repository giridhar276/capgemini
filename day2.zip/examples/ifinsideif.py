


name = input("Enter any string :")


if len(name) > 0 :
    if name.islower():
        print("String is lower")
    else:
        print("String is upper")
else:
    print("String is empty ... Cannot check the case")
