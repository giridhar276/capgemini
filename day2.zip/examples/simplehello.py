

print("Python programming")
print('Unix shell scripting')
