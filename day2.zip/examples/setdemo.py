



aset = {10,20,30,10,20,40,50}

print(aset)

