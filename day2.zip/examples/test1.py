

a= int(input("Enter any value :")) 
b= int(input("Enter any value :")

if a<b : 
    print (" a is less value") 
    print("inside ifblock") 
else: 
    print ("b is less") 
    print("inside else block") 
print("outside else block")


