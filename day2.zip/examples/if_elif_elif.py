
a = 10
b = 20

color = input("Enter any color :")

if color == "red":
    
    print("color is red")
elif color == "white":
    print("color is pink")
elif color == "black":
    print("color is black")
else:
    print("Its someother different color")

print("Out of if-else block")
