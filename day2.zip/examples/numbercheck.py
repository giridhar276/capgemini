



a = 10
b = 20

if a < b :
    print("Inside if condition")
    print("A is less than B")
else:
    print("inside else condition")
    print("B is less than B")

print("Out of if-else block")


    
