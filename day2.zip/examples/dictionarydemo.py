


book   = {"chap1":10  , "chap2":20  , "chap3":30 ,"chap1":1000 }

print(book)
print(book["chap1"])

info   = {"py":[10,20,30] , "sh":[40,50,60],"java":[50,60,70]}
print(info)
print(info["py"])       # [10,20,30]
print(info["py"][0])    # 10
