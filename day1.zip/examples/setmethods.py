

aset = {10,20,30,10,40}

bset = {40,50,60}

print(aset.union(bset))

print(aset.intersection(bset))

alist =[10,20,30,10,20]

print(set(alist))

hosts =["google.com","facebook.com","google.com","google.com"]

print(tuple(set(hosts)))
