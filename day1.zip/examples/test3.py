

name = input("Enter filename with extension") 
print("Entered file name is ", name) 
listactulextension = name.split(".") 
actualfilename = listactulextension[0] 
extension = listactulextension[1] 
print(actualfile) 
print(extension)
